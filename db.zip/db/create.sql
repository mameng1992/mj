-- we don't know how to generate schema MJ (class Schema) :(
create table BU_IGNORE_SERVICE
(
	URL varchar(50) collate utf8mb4_bin not null
		primary key,
	constraint BU_INGORE_SERVICE_URL_uindex
		unique (URL)
)
;

create table BU_LOGIN
(
	LOGIN_NAME varchar(20) collate utf8mb4_bin not null
		primary key,
	LOGIN_STATUS int not null,
	LOGIN_DATA datetime not null,
	LOGIN_COUNT int not null
)
;

create table SYS_AUTHORITY
(
	ID varchar(20) not null
		primary key,
	AUTHORITY_NAME varchar(20) charset utf8 not null,
	AUTHORITY_LEVEL int(1) not null,
	AUTHORITY_PARENT_ID varchar(20) null,
	AUTHORITY_TYPE int not null
)
;

create table SYS_AUTHORITY_RESOURCE
(
	AUTHORITY_ID varchar(20) not null,
	RESOURCE_ID varchar(20) not null,
	primary key (AUTHORITY_ID, RESOURCE_ID)
)
;

create table SYS_DICT
(
	ID varchar(8) not null
		primary key,
	PARENT_ID varchar(8) null,
	DICT_LEVEL int(1) not null,
	DICT_NAME varchar(50) not null,
	DICT_VALUE varchar(50) null
)
;

create table SYS_ERROR_INFO
(
	ERROR_CODE varchar(6) not null
		primary key,
	ERROR_MSG varchar(100) not null,
	ERROR_TYPE int not null,
	constraint SYS_ERROR_INFO_ERROR_CODE_uindex
		unique (ERROR_CODE)
)
;

create table SYS_MENU
(
	ID varchar(20) not null
		primary key,
	MENU_NAME varchar(50) not null,
	MENU_URL varchar(50) not null,
	MENU_LEVEL int(2) not null,
	PARENT_ID varchar(50) null,
	MENU_INDEX int(2) not null
)
;

create table SYS_RESOURCE
(
	ID varchar(20) not null
		primary key,
	URL varchar(100) collate utf8mb4_bin not null,
	URL_NAME varchar(20) null
)
;

create table SYS_ROLE
(
	ID varchar(20) not null
		primary key,
	ROLE_NAME varchar(20) charset utf8 not null,
	ROLE_LEVEL int(1) not null,
	ROLE_PARENT_ID varchar(20) null,
	ROLE_INDEX int(1) not null
)
;

create table SYS_ROLE_AUTHORITY
(
	ROLE_ID varchar(20) not null,
	AUTHORITY_ID varchar(20) not null,
	primary key (AUTHORITY_ID, ROLE_ID)
)
;

create table SYS_USER
(
	ID varchar(20) not null
		primary key,
	NICK_NAME varchar(20) not null,
	MOBILE_PHONE varchar(13) null,
	USER_STATUS int not null,
	CREATE_TIME timestamp default CURRENT_TIMESTAMP not null
)
;

create table SYS_USER_AUTH
(
	ID varchar(20) not null
		primary key,
	USER_ID varchar(20) not null,
	AUTH_TYPE varchar(2) not null,
	IDENTIFIER varchar(20) collate utf8mb4_bin not null,
	CREDENTIAL varchar(60) collate utf8mb4_bin null
)
;

create table SYS_USER_ROLE
(
	USER_ID varchar(20) not null,
	ROLE_ID varchar(20) not null,
	primary key (USER_ID, ROLE_ID)
)
;

